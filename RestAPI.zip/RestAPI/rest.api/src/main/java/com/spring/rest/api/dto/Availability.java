package com.spring.rest.api.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;


@Getter @Setter
@AllArgsConstructor
public class Availability {
    
    private String storeNo ;
    private String productId;
    private java.util.Date date;
    private Double availQty;
}
