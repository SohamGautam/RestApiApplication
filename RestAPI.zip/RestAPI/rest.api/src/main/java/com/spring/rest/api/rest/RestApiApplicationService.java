package com.spring.rest.api.rest;

import com.spring.rest.api.dto.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.*;
import org.springframework.stereotype.Service;


@Service
public class RestApiApplicationService {

    //Problem 1
    public String invPicture( String productId, String prodName, Date reqDate){
        return null;
    }
    //Problem 2
    public String prodAvailability(String storeNo, String productId, Double reqQty, Date reqDate){
        return null;
    }

    //Problem 3
    public Map<String, Object> orderStats(String statName){
        
        List<Order> orders = getOrderRecords();
        Map<String, Object> response = new HashMap<>();

        if ("MAX_SALE".equals(statName)) {
            Map<String, List<Order>> groupedByProduct = orders.stream()
                    .collect(Collectors.groupingBy(Order::getProductId));

            Optional<Map.Entry<String, Double>> maxProduct = groupedByProduct.entrySet().stream()
                    .collect(Collectors.toMap(Map.Entry::getKey,
                            entry -> entry.getValue().stream().mapToDouble(Order::getQuantity).sum()))
                    .entrySet().stream().max(Comparator.comparingDouble(Map.Entry::getValue));

            if (maxProduct.isPresent()) {
                String productId = maxProduct.get().getKey();
                List<Order> ordersForMaxProduct = groupedByProduct.get(productId);
                ordersForMaxProduct.sort(Comparator.comparing(Order::getQuantity).reversed());

                response.put("productId", productId);
                response.put("orderList", ordersForMaxProduct);
            }
        } else if ("MIN_SALE".equals(statName)) {
            Map<String, Double> totalQuantityByProduct = orders.stream()
                    .collect(Collectors.groupingBy(Order::getProductId,
                            Collectors.summingDouble(Order::getQuantity)));

            Optional<Map.Entry<String, Double>> minProduct = totalQuantityByProduct.entrySet().stream()
                    .min(Comparator.comparingDouble(Map.Entry::getValue));

            if (minProduct.isPresent()) {
                String productId = minProduct.get().getKey();
                List<Order> ordersForMinProduct = orders.stream()
                        .filter(order -> order.getProductId().equals(productId))
                        .collect(Collectors.toList());

                ordersForMinProduct.sort(Comparator.comparing(Order::getQuantity).reversed());

                response.put("productId", productId);
                response.put("orderList", ordersForMinProduct);
            }
        }
        return response;
    }

    private List<Order> getOrderRecords() {
        // Create a hardcoded list of Order Records
        List<Order> orders = new ArrayList<>();
        try {
            orders.add(new Order("Order1", "Product1", new SimpleDateFormat("yyyy-MM-dd").parse("2021-03-16"), 10.0));
            orders.add(new Order("Order2", "Product2", new SimpleDateFormat("yyyy-MM-dd").parse("2021-03-19"), 5.0));
            orders.add(new Order("Order3", "Product1", new SimpleDateFormat("yyyy-MM-dd").parse("2021-03-16"), 30.0));
            orders.add(new Order("Order4", "Product4", new SimpleDateFormat("yyyy-MM-dd").parse("2021-03-20"), 20.0));
            orders.add(new Order("Order5", "Product2", new SimpleDateFormat("yyyy-MM-dd").parse("2021-03-16"), 20.0));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orders;
    }
}
