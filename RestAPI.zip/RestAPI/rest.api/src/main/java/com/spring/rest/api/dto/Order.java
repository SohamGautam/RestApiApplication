package com.spring.rest.api.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter @Setter
public class Order {
    
    private String orderNo;
    private String productId;
    private Date createDate;
    private Double quantity;

    public Order(String orderNo, String productId, Date createDate, Double quantity) {
        this.orderNo = orderNo;
        this.productId = productId;
        this.createDate = createDate;
        this.quantity = quantity;
    }

}
