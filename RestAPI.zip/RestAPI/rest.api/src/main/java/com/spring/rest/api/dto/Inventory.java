package com.spring.rest.api.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;

import java.util.Date;

@Getter @Setter
@AllArgsConstructor
public class Inventory {
     
    private String productid;
    private String prodName ;
    private String UOM;
    private Double availQty;
    private Date  availDate;
}
