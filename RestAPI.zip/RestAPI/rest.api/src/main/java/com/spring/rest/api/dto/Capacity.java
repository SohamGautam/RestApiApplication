package com.spring.rest.api.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;

import java.util.Date;

@Getter @Setter
@AllArgsConstructor
public class Capacity {
    private String storeNo;
    private Date date;
    private Double noOfOrdersAccepted;
}
