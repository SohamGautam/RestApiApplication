package com.spring.rest.api.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.Map;

@RestController
public class RestApiApplicationController {

    @Autowired
    RestApiApplicationService service;

    // Problem 1
    @GetMapping("getInvPicture")
    //URL: getInvPicture?productId=Prod1&prodName=Shirt&reqDate=2021-03-19
    public String getInvPicture(@RequestParam(required = true) String productId,
            @RequestParam(required = true) String prodName,
            @RequestParam(required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date reqDate) {

        return service.invPicture(productId, prodName,reqDate);

    }

    // Problem 2
    @GetMapping("getProdAvailability")
    //URL: getProdAvailability?storeNo=Store001&productId=Prod1&reqQty=2&reqDate=2021-02-19
    public String getProdAvailability(@RequestParam(required = true) String storeNo,
            @RequestParam(required = true) String productId,
            @RequestParam(required = true) Double reqQty,
            @RequestParam(required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date reqDate) {

        return service.prodAvailability(storeNo, productId, reqQty, reqDate);
    }

    // Problem 3
    @GetMapping("getOrderStats")  
    //URL: getOrderStats?statName=MAX_SALE
    public Map<String, Object> getOrderStats(@RequestParam(required = true) String statName) {
        return service.orderStats(statName);
    }

}
